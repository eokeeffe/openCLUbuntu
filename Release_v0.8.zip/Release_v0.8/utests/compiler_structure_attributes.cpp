#include "utest_helper.hpp"

void compiler_structure_attributes(void)
{
  OCL_CREATE_KERNEL("compiler_structure_attributes");
}

MAKE_UTEST_FROM_FUNCTION(compiler_structure_attributes);

