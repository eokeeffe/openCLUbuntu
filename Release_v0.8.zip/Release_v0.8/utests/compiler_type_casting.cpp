#include "utest_helper.hpp"

void compiler_type_casting(void)
{
  OCL_CREATE_KERNEL("compiler_type_casting");
}

MAKE_UTEST_FROM_FUNCTION(compiler_type_casting);


