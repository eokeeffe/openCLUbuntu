#include "utest_helper.hpp"

void compiler_preprocessor_macros(void)
{
  OCL_CREATE_KERNEL("compiler_preprocessor_macros");
}

MAKE_UTEST_FROM_FUNCTION(compiler_preprocessor_macros);

