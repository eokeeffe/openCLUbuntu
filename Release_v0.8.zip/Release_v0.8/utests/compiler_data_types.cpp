#include "utest_helper.hpp"

void compiler_data_types(void)
{
  OCL_CREATE_KERNEL("compiler_data_types");
}

MAKE_UTEST_FROM_FUNCTION(compiler_data_types);

