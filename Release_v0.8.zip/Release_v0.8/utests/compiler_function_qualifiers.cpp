#include "utest_helper.hpp"

void compiler_function_qualifiers(void)
{
  OCL_CREATE_KERNEL("compiler_function_qualifiers");
}

MAKE_UTEST_FROM_FUNCTION(compiler_function_qualifiers);


