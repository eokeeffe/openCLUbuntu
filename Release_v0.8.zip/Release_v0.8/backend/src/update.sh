#! /bin/sh -e
./update_as.sh
./update_convert.sh
