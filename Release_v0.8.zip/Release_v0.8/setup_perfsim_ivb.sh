export INTEL_DEVID_OVERRIDE=0x0166     # or, 0x0112
export DEVICE=ivb_m_gt2                #     snb_gt2 for SNB GT2 desktop
export OCL_SIMULATOR=2                 # 0 -> HW, 1 -> fulsim, 2 -> perfsim

